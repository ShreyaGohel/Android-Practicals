package com.example.practical_14;

public class contactModel {

    // Initialize variable

    String name,number;

    // Generate getter & setter


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
